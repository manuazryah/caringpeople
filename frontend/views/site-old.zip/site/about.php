<div class="mkdf-content">
    <div class="mkdf-content-inner">
        <div class="mkdf-title mkdf-standard-type mkdf-preload-background mkdf-has-background mkdf-has-parallax-background mkdf-content-center-alignment mkdf-animation-no mkdf-title-image-not-responsive" style="color:#ffffff;;background-image:url(images/banner/4.png);;height:385px;;border-bottom: none" data-height="385" data-background-width=&quot;1920&quot;>
            <div class="mkdf-title-image"><img src="<?= Yii::$app->homeUrl; ?>images/banner/2.png" alt="&nbsp;" /> </div>
            <div class="mkdf-title-holder" style="height:385px;">
                <div class="mkdf-container clearfix">
<!--                    <div class="mkdf-container-inner">
                        <div class="mkdf-title-subtitle-holder" style="">
                            <div class="mkdf-title-subtitle-holder-inner">
                                <h1 style="color:#ffffff;"><span>About Us</span></h1>
                                <span class="mkdf-subtitle" style="color:#ffffff;"><span>Who We Are And What We Do</span></span>
                            </div>
                        </div>
                    </div>-->
                </div>
            </div>
        </div>

        <div id="about" class="mkdf-full-width">
            <div class="mkdf-full-width-inner">
                <div class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1453715001552 mkdf-content-aligment-left mkdf-grid-section" style="">
                    <div class="clearfix mkdf-section-inner">
                        <div class="mkdf-section-inner-margin clearfix">
                            <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-12 vc_col-md-12">
                                <div class="vc_column-inner vc_custom_1455193090176">
                                    <div class="wpb_wrapper">
                                        <div class="mkdf-section-title-holder">
                                            <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                About Us</h2>
                                        </div>
                                        <div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-full-width">
                                            <div class="mkdf-separator" style="border-color: #eaeaea;border-bottom-width: 1px;margin-top: 25px;margin-bottom: 25px"></div>
                                        </div>
                                        <div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left">
                                            <p style="text-align: left" class="mkdf-section-subtitle">Caring People is a highly distinct firm specializing as an in-home service provider, which supports the clients by offering comprehensive services so as to lead dignified and independent lifestyles in the comfort and safety of their own homes. We are a professional team designed to provide an outstanding service to our clients. We are dedicated to offer quality, ethical and professional services. The services we deliver include Nursing Care, Doctor Visit at Home, Health Monitoring, Physiotherapy, Bystander or Caregiver Service and Companion Care. In addition, we offer no-cost, no-obligation in-home consultations and custom designed payment plans. Please be aware that we provide only planned and prior appointment services.</p>
                                        </div>
                                        <div data-original-height="25" class="vc_empty_space" style="height: 25px"><span class="vc_empty_space_inner"></span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1453458798017 mkdf-content-aligment-center mkdf-grid-section" style="">
                    <div class="clearfix mkdf-section-inner">
                        <div class="mkdf-section-inner-margin clearfix">
                            <div class="wpb_column vc_column_container vc_col-sm-12">
                                <div class="vc_column-inner ">
                                    <div class="wpb_wrapper">
                                        <div class="mkdf-section-title-holder">
                                            <h2 class="mkdf-section-title mkdf-section-title-large" style="text-align: center">
                                                Our Team</h2>
                                        </div>
<!--                                        <div class="mkdf-section-subtitle-holder mkdf-section-subtitle-center" style="width: 58%">
                                            <p style="text-align: center" class="mkdf-section-subtitle">Lorem ipsum dolor sit amet facilisis sed vitae lorem pede at eu arcu vulputate metus luctus ut quis vivamus vitae id habitasse et morbi</p>
                                        </div>-->
                                        <!--<div data-original-height="74" class="vc_empty_space" style="height: 74px"><span class="vc_empty_space_inner"></span></div>-->
                                        <div data-mkdf-parallax-speed="1" class="vc_row wpb_row vc_inner vc_row-fluid mkdf-section mkdf-content-aligment-left" style="">
                                            <div class="mkdf-full-section-inner">
                                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-12 vc_col-md-12">
                                                    <div class="vc_column-inner vc_custom_1453459136394">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 200ms;-webkit-animation-delay: 200ms;animation-delay: 200ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/patron-1.png" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JOSE MARADIKUNNEL							</h4>
                                                                                    <h6 class="mkdf-team-position ">Patron</h6>
                                                                                </div>

                                                                                <!--                                                                                                <div class='mkdf-team-text'>
                                                                                                                                                                                    <div class='mkdf-team-text-inner'>
                                                                                                                                                                                        <div class='mkdf-team-description '>
                                                                                                                                                                                        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean feugiat dictum lacus, ut hendrerit mi pulvinar vel. Fusce id nibh at neque eleifend tristique at sit amet libero</p>
                                                                                                                                                                                        </div>
                                                                                                                                                                                    </div>
                                                                                                                                                                                </div>-->

                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_text_column wpb_content_element vc_col-md-12 vc_col-sm-12 vc_col-xs-12  ">
                                                    <div class="wpb_wrapper">
                                                        <h3>Management Team</h3>

                                                    </div>
                                                </div>
                                                <div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-full-width">
                                                    <div class="mkdf-separator" style="border-color: #eaeaea;border-bottom-width: 1px;margin-top: 25px;margin-bottom: 25px"></div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-4 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/shinto.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        SHINTO JOSE							</h4>
                                                                                    <h6 class="mkdf-team-position ">Founder & CEO</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-4 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459158369">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 600ms;-webkit-animation-delay: 600ms;animation-delay: 600ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/jinto.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JINTO JOSE							</h4>
                                                                                    <h6 class="mkdf-team-position ">General Manager</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-4 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/susan.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JESSY SUSAN ABRAHAM							</h4>
                                                                                    <h6 class="mkdf-team-position ">Director of Nursing</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="wpb_text_column wpb_content_element vc_col-md-12 vc_col-sm-12 vc_col-xs-12 ">
                                                    <div class="wpb_wrapper">
                                                        <h3>Administrative Panel</h3>

                                                    </div>
                                                </div>
                                                <div class="mkdf-separator-holder clearfix  mkdf-separator-center mkdf-separator-full-width">
                                                    <div class="mkdf-separator" style="border-color: #eaeaea;border-bottom-width: 1px;margin-top: 25px;margin-bottom: 25px"></div>
                                                </div>

                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/jilson.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JILSON JOSE							</h4>
                                                                                    <h6 class="mkdf-team-position ">Chief Operating Officer – Mumbai</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/nixy-1.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        NIXY P CHERIAN						</h4>
                                                                                    <h6 class="mkdf-team-position ">Nurse Manager – Cochin</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/omal.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        OMAL SEBASTIAN						</h4>
                                                                                    <h6 class="mkdf-team-position ">Nurse Manager – Mumbai</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/joicy.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JOICY						</h4>
                                                                                    <h6 class="mkdf-team-position ">Nurse Manager – Mumbai</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/jabir.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        DR JABIR ABDULLAKUTTY						</h4>
                                                                                    <h6 class="mkdf-team-position ">Clinical Adviser</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/meena.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        DR MEENA JAYARAM						</h4>
                                                                                    <h6 class="mkdf-team-position ">Medical Officer</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/dany.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        DANY JOSE						</h4>
                                                                                    <h6 class="mkdf-team-position ">Dep. of Physiotherapy</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/jessy.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JESSY MARIAMMA VARGHESE						</h4>
                                                                                    <h6 class="mkdf-team-position ">Nurse Consultant</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/vakknal.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        ADV. ABRAHAM VAKKANAL						</h4>
                                                                                    <h6 class="mkdf-team-position ">Legal Adviser</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/sebi.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        SEBI GEORGE						</h4>
                                                                                    <h6 class="mkdf-team-position ">Business and Finance Consultant</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/bastin.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        BASTIN V S						</h4>
                                                                                    <h6 class="mkdf-team-position ">IT Consultant</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/jisny.png" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        JISMY GEORGE						</h4>
                                                                                    <h6 class="mkdf-team-position ">IT Consultant</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/grav.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        AJIN CHACKO						</h4>
                                                                                    <h6 class="mkdf-team-position ">Online Marketing</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/shino.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        SHINO VARGHESE						</h4>
                                                                                    <h6 class="mkdf-team-position ">Media Consultant</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="wpb_column vc_column_container vc_col-sm-4 vc_col-xs-6 vc_col-lg-3 vc_col-md-4">
                                                    <div class="vc_column-inner vc_custom_1453459152818">
                                                        <div class="wpb_wrapper">
                                                            <div class="mkdf-animations-holder mkdf-element-from-fade" data-animation="mkdf-element-from-fade">
                                                                <div style="transition-delay: 400ms;-webkit-animation-delay: 400ms;animation-delay: 400ms;animation-duration: 700ms;-webkit-animation-duration: 700ms;-moz-animation-duration: 700ms">

                                                                    <div class="mkdf-team main-info-below-image">
                                                                        <div class="mkdf-team-inner">
                                                                            <div class="mkdf-team-image">
                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/team/pro.jpg" alt="mkdf-team-image" />
                                                                            </div>

                                                                            <div class="mkdf-team-info">
                                                                                <div class="mkdf-team-title-holder circle">
                                                                                    <h4 class="mkdf-team-name ">
                                                                                        ALEX JOHNY						</h4>
                                                                                    <h6 class="mkdf-team-position ">Public Relation Officer</h6>
                                                                                </div>


                                                                                <div class="mkdf-team-social-holder-between">
                                                                                    <div class="mkdf-team-social circle">
                                                                                        <div class="mkdf-team-social-inner">
                                                                                            <div class="mkdf-team-social-wrapp">

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://twitter.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_twitter mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://www.facebook.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_facebook mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://plus.google.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_googleplus mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                                <span class="mkdf-icon-shortcode circle ">
                                                                                                    <a href="https://vimeo.com/" target="_blank">

                                                                                                        <span aria-hidden="true" class="mkdf-icon-font-elegant social_vimeo mkdf-icon-element" style="" ></span>
                                                                                                    </a>
                                                                                                </span>

                                                                                            </div>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    <div data-original-height="40" class="vc_empty_space" style="height: 40px"><span class="vc_empty_space_inner"></span></div>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- close div.content_inner -->
</div>
