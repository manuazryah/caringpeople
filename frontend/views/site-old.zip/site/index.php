<div class="mkdf-content">
        <div class="mkdf-content-inner">
                <div class="mkdf-full-width">
                        <div class="mkdf-full-width-inner">
                                <div class="vc_row wpb_row vc_row-fluid mkdf-section mkdf-content-aligment-left" style="">
                                        <div class="clearfix mkdf-full-section-inner">
                                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                                        <div class="vc_column-inner ">
                                                                <div class="wpb_wrapper">
                                                                        <div class="wpb_revslider_element wpb_content_element">
                                                                                <link href="http://fonts.googleapis.com/css?family=Josefin%20Sans:700" rel="stylesheet" property="stylesheet" type="text/css" media="all" />
                                                                                <link href="http://fonts.googleapis.com/css?family=Open%20Sans:400,700" rel="stylesheet" property="stylesheet" type="text/css" media="all" />
                                                                                <div id="rev_slider_11_1_wrapper" class="rev_slider_wrapper fullscreen-container" style="background-color:transparent;padding:0px;">
                                                                                        <div id="rev_slider_11_1" class="rev_slider fullscreenbanner" style="display:none;" data-version="5.1.6">
                                                                                                <ul>
                                                                                                        <li data-index="rs-115" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/home-1-slide-4-100x50.jpg" data-delay="5000" data-rotate="0" data-fstransition="fade" data-fsmasterspeed="500" data-fsslotamount="7" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/banner/1.png" alt="q" width="1920" height="1000" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

                                                                                                                <div class="tp-caption Default-Title-1 tp-layer-selectable  tp-resizeme" id="slide-115-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-90','-85','-150','-144']" data-fontsize="['75','73','75','55']" data-lineheight="['80','80','80','65']" data-width="['none','none','606','457']" data-height="['none','none','161','131']" data-whitespace="['nowrap','nowrap','normal','normal']" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:800;" data-start="800" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4900" style="z-index: 5; white-space: nowrap;text-align:center;">Nurturing Body and Mind.
                                                                                                                </div>

                                                                                                                <!--                                                        <div class="tp-caption Default-Subtitle tp-layer-selectable  tp-resizeme" id="slide-115-layer-6" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','5','0','0']" data-fontsize="['22','22','22','20']" data-lineheight="['36','36','36','33']" data-width="['980','980','626','407']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4800" style="z-index: 6; min-width: 980px; max-width: 980px; white-space: normal; font-size: 22px; line-height: 36px; color: rgba(255, 255, 255, 1.00);text-align:center;">Lorem ipsum dolor. Sit amet pellentesque. Nec sociis urna. Dui quam vestibulum. Luctus a vel scelerisque ornare vivamus. Eleifend in cubilia.
                                                                                                                                                                        </div>-->

                                                                                                                <!--                                                                        <div class="tp-caption Button rev-btn tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                                 id="slide-115-layer-4"
                                                                                                                                                                                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                                 data-y="['middle','middle','middle','middle']" data-voffset="['110','115','110','130']"
                                                                                                                                                                                                 data-width="none"
                                                                                                                                                                                                 data-height="none"
                                                                                                                                                                                                 data-whitespace="nowrap"
                                                                                                                                                                                                 data-transform_idle="o:1;"
                                                                                                                                                                                                 data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:200;e:Linear.easeNone;"
                                                                                                                                                                                                 data-style_hover="c:rgba(79, 191, 112, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);"

                                                                                                                                                                                                 data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                                 data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                                 data-start="1200"
                                                                                                                                                                                                 data-splitin="none"
                                                                                                                                                                                                 data-splitout="none"
                                                                                                                                                                                                 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"http:\/\/themeforest.net\/item\/wellspring-a-health-lifestyle-fitness-theme\/14994151"}]'
                                                                                                                                                                                                 data-responsive_offset="on"

                                                                                                                                                                                                 data-end="4700"

                                                                                                                                                                                                 style="z-index: 7; white-space: nowrap;padding:19px 48px 19px 48px;border-width:0px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Purchase
                                                                                                                                                                                            </div>-->
                                                                                                        </li>
                                                                                                        <li data-index="rs-122" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/home-1-slide-1-100x50.jpg" data-delay="5000" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/banner/3.png" alt="q" width="1920" height="1100" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

                                                                                                                <div class="tp-caption tp-layer-selectable  tp-resizeme" id="slide-122-layer-5" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-160','-155','-210','-190']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="800" data-responsive_offset="on" data-end="4990" style="z-index: 5;">
                                                                                                                    <!--<img src="<?= Yii::$app->homeUrl; ?><images/f-logo.png" alt="q" width="103" height="103" data-ww="['103px','103px','103px','92px']" data-hh="['103px','103px','103px','92px']" data-no-retina> -->
                                                                                                                </div>

                                                                                                                <div class="tp-caption Default-Title-1 tp-layer-selectable  tp-resizeme" id="slide-122-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-40','-30','-50','-55']" data-fontsize="['75','73','75','55']" data-lineheight="['80','80','80','65']" data-width="['none','none','626','479']" data-height="none" data-whitespace="['nowrap','nowrap','normal','normal']" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:800;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4900" style="z-index: 6; white-space: nowrap;text-align:center;">Keeping Your Body at its Best.
                                                                                                                </div>

                                                                                                                <!--                                                        <div class="tp-caption Default-Subtitle tp-layer-selectable  tp-resizeme" id="slide-122-layer-6" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['55','65','105','85']" data-fontsize="['22','22','22','20']" data-lineheight="['36','36','36','33']" data-width="['980','980','626','407']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4800" style="z-index: 7; min-width: 980px; max-width: 980px; white-space: normal; font-size: 22px; line-height: 36px; color: rgba(255, 255, 255, 1.00);text-align:center;">Lorem ipsum dolor. Sit amet pellentesque. Nec sociis urna. Dui quam vestibulum. Luctus a vel scelerisque ornare vivamus. Eleifend in cubilia.
                                                                                                                                                                        </div>-->

                                                                                                                <!--                                                                        <div class="tp-caption Button rev-btn tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                                 id="slide-122-layer-4"
                                                                                                                                                                                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                                 data-y="['middle','middle','middle','middle']" data-voffset="['160','170','220','220']"
                                                                                                                                                                                                 data-width="none"
                                                                                                                                                                                                 data-height="none"
                                                                                                                                                                                                 data-whitespace="nowrap"
                                                                                                                                                                                                 data-transform_idle="o:1;"
                                                                                                                                                                                                 data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:200;e:Linear.easeNone;"
                                                                                                                                                                                                 data-style_hover="c:rgba(79, 191, 112, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);"

                                                                                                                                                                                                 data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                                 data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                                 data-start="1400"
                                                                                                                                                                                                 data-splitin="none"
                                                                                                                                                                                                 data-splitout="none"
                                                                                                                                                                                                 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"http:\/\/themeforest.net\/item\/wellspring-a-health-lifestyle-fitness-theme\/14994151"}]'
                                                                                                                                                                                                 data-responsive_offset="on"

                                                                                                                                                                                                 data-end="4700"

                                                                                                                                                                                                 style="z-index: 8; white-space: nowrap;padding:19px 48px 19px 48px;border-width:0px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Purchase
                                                                                                                                                                                            </div>-->
                                                                                                        </li>
                                                                                                        <li data-index="rs-124" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/home-1-slide-6-100x50.jpg" data-delay="5000" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/banner/2.png" alt="q" width="1920" height="1000" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

                                                                                                                <div class="tp-caption tp-layer-selectable  tp-resizeme" id="slide-124-layer-5" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-160','-155','-210','-190']" data-width="none" data-height="none" data-whitespace="nowrap" data-transform_idle="o:1;" data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="800" data-responsive_offset="on" data-end="4990" style="z-index: 5;">
                                                                                                                    <!--<img src="<?= Yii::$app->homeUrl; ?>images/f-logo.png" alt="q" width="103" height="103" data-ww="['103px','103px','103px','92px']" data-hh="['103px','103px','103px','92px']" data-no-retina> -->
                                                                                                                </div>

                                                                                                                <div class="tp-caption Default-Title-1 tp-layer-selectable  tp-resizeme" id="slide-124-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-40','-30','-50','-55']" data-fontsize="['75','73','75','55']" data-lineheight="['80','80','80','65']" data-width="['none','none','626','479']" data-height="none" data-whitespace="['nowrap','nowrap','normal','normal']" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:800;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4900" style="z-index: 6; white-space: nowrap;text-align:center;">Experience the Difference.
                                                                                                                </div>

                                                                                                                <!--                                                        <div class="tp-caption Default-Subtitle tp-layer-selectable  tp-resizeme" id="slide-124-layer-6" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['55','65','105','85']" data-fontsize="['22','22','22','20']" data-lineheight="['36','36','36','33']" data-width="['980','980','626','407']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="1200" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4800" style="z-index: 7; min-width: 980px; max-width: 980px; white-space: normal; font-size: 22px; line-height: 36px; color: rgba(255, 255, 255, 1.00);text-align:center;">Lorem ipsum dolor. Sit amet pellentesque. Nec sociis urna. Dui quam vestibulum. Luctus a vel scelerisque ornare vivamus. Eleifend in cubilia.
                                                                                                                                                                        </div>-->

                                                                                                                <!--                                                                        <div class="tp-caption Button rev-btn tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                                 id="slide-124-layer-4"
                                                                                                                                                                                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                                 data-y="['middle','middle','middle','middle']" data-voffset="['160','170','220','220']"
                                                                                                                                                                                                 data-width="none"
                                                                                                                                                                                                 data-height="none"
                                                                                                                                                                                                 data-whitespace="nowrap"
                                                                                                                                                                                                 data-transform_idle="o:1;"
                                                                                                                                                                                                 data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:200;e:Linear.easeNone;"
                                                                                                                                                                                                 data-style_hover="c:rgba(79, 191, 112, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);"

                                                                                                                                                                                                 data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                                 data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                                 data-start="1400"
                                                                                                                                                                                                 data-splitin="none"
                                                                                                                                                                                                 data-splitout="none"
                                                                                                                                                                                                 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"http:\/\/themeforest.net\/item\/wellspring-a-health-lifestyle-fitness-theme\/14994151"}]'
                                                                                                                                                                                                 data-responsive_offset="on"

                                                                                                                                                                                                 data-end="4700"

                                                                                                                                                                                                 style="z-index: 8; white-space: nowrap;padding:19px 48px 19px 48px;border-width:0px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Purchase
                                                                                                                                                                                            </div>-->
                                                                                                        </li>
                                                                                                        <li data-index="rs-123" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off" data-easein="default" data-easeout="default" data-masterspeed="default" data-thumb="http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/home-1-slide-2-100x50.jpg" data-delay="5000" data-rotate="0" data-saveperformance="off" data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                                                                                                <img src="<?= Yii::$app->homeUrl; ?>images/banner/4.png" alt="q" width="1920" height="1000" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

                                                                                                                <div class="tp-caption Default-Title-1 tp-layer-selectable  tp-resizeme" id="slide-123-layer-1" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['-90','-85','-150','-145']" data-fontsize="['75','73','75','55']" data-lineheight="['80','80','80','65']" data-width="['none','none','626','479']" data-height="none" data-whitespace="['nowrap','nowrap','normal','normal']" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:800;" data-start="800" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4900" style="z-index: 5; white-space: nowrap;text-align:center;">Your Place to Discover Wellness.
                                                                                                                </div>

                                                                                                                <!--                                                        <div class="tp-caption Default-Subtitle tp-layer-selectable  tp-resizeme" id="slide-123-layer-6" data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']" data-y="['middle','middle','middle','middle']" data-voffset="['0','5','0','0']" data-fontsize="['22','22','22','20']" data-lineheight="['36','36','36','33']" data-width="['980','980','626','407']" data-height="none" data-whitespace="normal" data-transform_idle="o:1;" data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;" data-transform_out="auto:auto;s:600;" data-start="1000" data-splitin="none" data-splitout="none" data-responsive_offset="on" data-end="4800" style="z-index: 6; min-width: 980px; max-width: 980px; white-space: normal; font-size: 22px; line-height: 36px; color: rgba(255, 255, 255, 1.00);text-align:center;">Lorem ipsum dolor. Sit amet pellentesque. Nec sociis urna. Dui quam vestibulum. Luctus a vel scelerisque ornare vivamus. Eleifend in cubilia.
                                                                                                                                                                        </div>-->

                                                                                                                <!--                                                                        <div class="tp-caption Button rev-btn tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                                 id="slide-123-layer-4"
                                                                                                                                                                                                 data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                                 data-y="['middle','middle','middle','middle']" data-voffset="['110','115','110','130']"
                                                                                                                                                                                                 data-width="none"
                                                                                                                                                                                                 data-height="none"
                                                                                                                                                                                                 data-whitespace="nowrap"
                                                                                                                                                                                                 data-transform_idle="o:1;"
                                                                                                                                                                                                 data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:200;e:Linear.easeNone;"
                                                                                                                                                                                                 data-style_hover="c:rgba(79, 191, 112, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);"

                                                                                                                                                                                                 data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                                 data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                                 data-start="1200"
                                                                                                                                                                                                 data-splitin="none"
                                                                                                                                                                                                 data-splitout="none"
                                                                                                                                                                                                 data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"http:\/\/themeforest.net\/item\/wellspring-a-health-lifestyle-fitness-theme\/14994151"}]'
                                                                                                                                                                                                 data-responsive_offset="on"

                                                                                                                                                                                                 data-end="4700"

                                                                                                                                                                                                 style="">
                                                                                                                                                                                            </div>-->
                                                                                                        </li>
                                                                                                        <!--                                                                    <li data-index="rs-112" data-transition="fade" data-slotamount="default" data-hideafterloop="0" data-hideslideonmobile="off"  data-easein="default" data-easeout="default" data-masterspeed="default"  data-thumb="http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/home-1-slide-5-100x50.jpg"  data-delay="5000"  data-rotate="0"  data-saveperformance="off"  data-title="Slide" data-param1="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-param10="" data-description="">
                                                                                                                                                                                    <img src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/02/home-1-slide-5.jpg"  alt="q"  width="1920" height="1000" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="5" class="rev-slidebg" data-no-retina>

                                                                                                                                                                                    <div class="tp-caption tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                         id="slide-112-layer-5"
                                                                                                                                                                                         data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                         data-y="['middle','middle','middle','middle']" data-voffset="['-160','-155','-210','-190']"
                                                                                                                                                                                         data-width="none"
                                                                                                                                                                                         data-height="none"
                                                                                                                                                                                         data-whitespace="nowrap"
                                                                                                                                                                                         data-transform_idle="o:1;"

                                                                                                                                                                                         data-transform_in="z:0;rX:0;rY:0;rZ:0;sX:0.9;sY:0.9;skX:0;skY:0;opacity:0;s:1500;e:Power3.easeOut;"
                                                                                                                                                                                         data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                         data-start="800"
                                                                                                                                                                                         data-responsive_offset="on"

                                                                                                                                                                                         data-end="4990"

                                                                                                                                                                                         style="z-index: 5;"><img src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/02/logo-slider.png" alt="q" width="103" height="103" data-ww="['103px','103px','103px','92px']" data-hh="['103px','103px','103px','92px']" data-no-retina>
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="tp-caption Default-Title-1 tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                         id="slide-112-layer-1"
                                                                                                                                                                                         data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                         data-y="['middle','middle','middle','middle']" data-voffset="['-40','-30','-50','-55']"
                                                                                                                                                                                         data-fontsize="['75','73','75','55']"
                                                                                                                                                                                         data-lineheight="['80','80','80','65']"
                                                                                                                                                                                         data-width="['none','none','626','455']"
                                                                                                                                                                                         data-height="['none','none','none','131']"
                                                                                                                                                                                         data-whitespace="['nowrap','nowrap','normal','normal']"
                                                                                                                                                                                         data-transform_idle="o:1;"

                                                                                                                                                                                         data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                         data-transform_out="auto:auto;s:800;"
                                                                                                                                                                                         data-start="1000"
                                                                                                                                                                                         data-splitin="none"
                                                                                                                                                                                         data-splitout="none"
                                                                                                                                                                                         data-responsive_offset="on"

                                                                                                                                                                                         data-end="4900"

                                                                                                                                                                                         style="z-index: 6; white-space: nowrap;text-align:center;">Beautiful Body. Built by You.
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="tp-caption Default-Subtitle tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                         id="slide-112-layer-6"
                                                                                                                                                                                         data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                         data-y="['middle','middle','middle','middle']" data-voffset="['55','65','105','85']"
                                                                                                                                                                                         data-fontsize="['22','22','22','20']"
                                                                                                                                                                                         data-lineheight="['36','36','36','33']"
                                                                                                                                                                                         data-width="['980','980','626','407']"
                                                                                                                                                                                         data-height="none"
                                                                                                                                                                                         data-whitespace="normal"
                                                                                                                                                                                         data-transform_idle="o:1;"

                                                                                                                                                                                         data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                         data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                         data-start="1200"
                                                                                                                                                                                         data-splitin="none"
                                                                                                                                                                                         data-splitout="none"
                                                                                                                                                                                         data-responsive_offset="on"

                                                                                                                                                                                         data-end="4800"

                                                                                                                                                                                         style="z-index: 7; min-width: 980px; max-width: 980px; white-space: normal; font-size: 22px; line-height: 36px; color: rgba(255, 255, 255, 1.00);text-align:center;">Lorem ipsum dolor. Sit amet pellentesque. Nec sociis urna. Dui quam vestibulum. Luctus a vel scelerisque ornare vivamus. Eleifend in cubilia.
                                                                                                                                                                                    </div>

                                                                                                                                                                                    <div class="tp-caption Button rev-btn tp-layer-selectable  tp-resizeme"
                                                                                                                                                                                         id="slide-112-layer-4"
                                                                                                                                                                                         data-x="['center','center','center','center']" data-hoffset="['0','0','0','0']"
                                                                                                                                                                                         data-y="['middle','middle','middle','middle']" data-voffset="['160','170','220','220']"
                                                                                                                                                                                         data-width="none"
                                                                                                                                                                                         data-height="none"
                                                                                                                                                                                         data-whitespace="nowrap"
                                                                                                                                                                                         data-transform_idle="o:1;"
                                                                                                                                                                                         data-transform_hover="o:1;rX:0;rY:0;rZ:0;z:0;s:200;e:Linear.easeNone;"
                                                                                                                                                                                         data-style_hover="c:rgba(79, 191, 112, 1.00);bg:rgba(255, 255, 255, 1.00);bc:rgba(255, 255, 255, 1.00);"

                                                                                                                                                                                         data-transform_in="y:50px;opacity:0;s:1000;e:Power3.easeOut;"
                                                                                                                                                                                         data-transform_out="auto:auto;s:600;"
                                                                                                                                                                                         data-start="1400"
                                                                                                                                                                                         data-splitin="none"
                                                                                                                                                                                         data-splitout="none"
                                                                                                                                                                                         data-actions='[{"event":"click","action":"simplelink","target":"_blank","url":"http:\/\/themeforest.net\/item\/wellspring-a-health-lifestyle-fitness-theme\/14994151"}]'
                                                                                                                                                                                         data-responsive_offset="on"

                                                                                                                                                                                         data-end="4700"

                                                                                                                                                                                         style="z-index: 8; white-space: nowrap;padding:19px 48px 19px 48px;border-width:0px;outline:none;box-shadow:none;box-sizing:border-box;-moz-box-sizing:border-box;-webkit-box-sizing:border-box;cursor:pointer;">Purchase
                                                                                                                                                                                    </div>
                                                                                                                                                                                </li>-->
                                                                                                </ul>
                                                                                                <div class="tp-bannertimer tp-bottom" style="visibility: hidden !important;"></div>
                                                                                        </div>
                                                                                        <script>
                                                                                                var htmlDivCss = ' #rev_slider_11_1_wrapper .tp-loader.spinner2{ background-color: #4fbf70 !important; } ';
                                                                                                var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                                                                                                if (htmlDiv) {
                                                                                                        htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                                                                                } else {
                                                                                                        var htmlDiv = document.createElement('div');
                                                                                                        htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                                                                        document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                                                                                                }
                                                                                        </script>
                                                                                        <script>
                                                                                                var htmlDivCss = unescape(".wellspring-light.tparrows%20%7B%0A%09width%3A60px%3B%0A%09height%3A60px%3B%0A%09background%3Atransparent%3B%0A%20%7D%0A%20.wellspring-light.tparrows%3Abefore%20%7B%0A%09width%3A60px%3B%0A%09height%3A60px%3B%0A%09line-height%3A72px%3B%0A%09font-size%3A60px%3B%0A%09transition%3Aall%200.3s%3B%0A%09-webkit-transition%3Aall%200.3s%3B%0A%09font-family%3A%20%27Linearicons-Free%27%3B%0A%20%7D%0A%20%0A.wellspring-light.tparrows%3Ahover%3Abefore%20%7B%0A%20%20%20%20opacity%3A0.75%3B%0A%7D%0A%20%20%0A.tparrows.tp-rightarrow%3A%3Abefore%20%7B%0A%20%20%09content%3A%20%27%5Ce876%27%3B%0A%7D%0A%20%20%0A.tparrows.tp-leftarrow%3A%3Abefore%20%7B%0A%20%20%09content%3A%20%27%5Ce875%27%3B%0A%7D%0A");
                                                                                                var htmlDiv = document.getElementById('rs-plugin-settings-inline-css');
                                                                                                if (htmlDiv) {
                                                                                                        htmlDiv.innerHTML = htmlDiv.innerHTML + htmlDivCss;
                                                                                                } else {
                                                                                                        var htmlDiv = document.createElement('div');
                                                                                                        htmlDiv.innerHTML = '<style>' + htmlDivCss + '</style>';
                                                                                                        document.getElementsByTagName('head')[0].appendChild(htmlDiv.childNodes[0]);
                                                                                                }
                                                                                        </script>
                                                                                </div>
                                                                                <!--END REVOLUTION SLIDER -->
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>

                                <!---------------------------------------------------------------header-end---------------------------------------------->


                                <!---------------------------------service-test------------------>

                                <div id="index-service-portfolio" class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1453372912921 mkdf-content-aligment-left mkdf-grid-section" style="padding-top: 40px !important;">
                                        <div class="clearfix mkdf-section-inner">
                                                <div class="mkdf-section-inner-margin clearfix">
                                                        <div class="wpb_column vc_column_container vc_col-sm-12">
                                                                <div class="vc_column-inner ">
                                                                        <div class="wpb_wrapper">
                                                                                <div class="mkdf-section-title-holder">
                                                                                        <h2 class="mkdf-section-title mkdf-section-title-large" style="text-align: center">
                                                                                                Our Services</h2>
                                                                                </div>
                                                                                <div class="mkdf-section-subtitle-holder mkdf-section-subtitle-center" style="width: 100%">
                                                                                        <p style="text-align: center" class="mkdf-section-subtitle">Caring People Home care offers the best quality care and support at home. Our aim is to enable our needy clients to continue living in their own households with dignity, individuality and with control over their lives, irrespective of the level of support required.</p>
                                                                                </div>
                                                                                <div data-original-height="74" class="vc_empty_space" style="height: 74px"><span class="vc_empty_space_inner"></span></div>
                                                                                <div class="mkdf-portfolio-slider-holder mkdf-carousel-pagination">
                                                                                        <ul class="mkdf-portfolio-slider-list" data-columns="3" data-enable-pagination="yes">
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1322 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/doctor-visit">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/doctor-visit.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-user-md attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                                <!--<img width="48" height="46" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/portfolio-custom-icon-1-1.png" class="attachment-thumbnail size-thumbnail" alt="p" /> -->
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/doctor-visit">Doctor Visit</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>We have a panel of highly skilled specialist doctors available for consultation, thus making your life easy. </p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/doctor-visit" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1323 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/nursing-care">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/palliative-care.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-care-staff-area attachment-thumbnail size-thumbnail" aria-hidden="true"></i>

                                                                <!--<img width="48" height="46" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/portfolio-custom-icon-2.png" class="attachment-thumbnail size-thumbnail" alt="p" />-->
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/nursing-care">Nursing Care (Palliative Care)</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Our fully qualified Live-in Nurses deliver a more comfortable and comforting alternative to hospital or nursing home care.</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/nursing-care" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1324 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/caregiver">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/caregiving-service.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-physical-therapy  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                                <!--<img width="48" height="46" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/portfolio-custom-icon-3-2.png" class="attachment-thumbnail size-thumbnail" alt="p" />-->
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/caregiver">Caregiving Services (24<span style="font-size: 14px;">&#10005;</span>7)</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Caring people’s care at home service offers the highest quality personal care and support at home. Our aim is to facilitate our clients remaining in ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/caregiver" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>

                                                                                        </ul>
                                                                                        <ul class="mkdf-portfolio-slider-list" data-columns="3" data-enable-pagination="yes">

                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1327 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/physiotherapy">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/Physiotherapy.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-pharmacy  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/physiotherapy">Physiotherapy</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/physiotherapy" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>



                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1327 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/pharmacy">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/pharmacy.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-pharmacy  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/pharmacy">Pharmacy</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>The scope of pharmacy practice includes more traditional roles such as compounding and dispensing medications, and it also includes ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/pharmacy" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1327 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/air-ambulance">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/air-ambulance.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-plane  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/pharmacy">Air Ambulance</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>We offer Air Ambulance Service to any destination in India in exclusive association with a leading air ambulance/air charter company. </p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/air-ambulance" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>


                                                                                        </ul>
                                                                                        <ul class="mkdf-portfolio-slider-list" data-columns="3" data-enable-pagination="yes">
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1338 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/equipment">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/medical-equipment.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-intensive-care  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/equipment">Equipment Hire or Purchase</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>You can hire or purchase any mobility or medical equipment you may require. Wheelchairs, Shower Chairs, Walkers, Medical beds, Standing and Rising ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/equipment" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>


                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/health-check-up">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/health-checkup.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-family-practice  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/health-check-up">Health Check-up</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>As the saying goes "Prevention is always better than cure". Over the last few years, medical science has rediscovered the value of Preventive Health Care.</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/health-check-up" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1325 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/laboratory">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/laboratory.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-laboratory  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/laboratory">Laboratory</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Caring People’s Lab offers a wide range of services to its clients. The speciality of this service is that the lab assistant comes to your home and collects ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/laboratory" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>

                                                                                        </ul>
                                                                                        <ul class="mkdf-portfolio-slider-list" data-columns="3" data-enable-pagination="yes">
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/mobile-pharmacy">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/mobile-pharmacy.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="icon-i-pharmacy  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/mobile-pharmacy">Mobile Pharmacy</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>We have highly trained and motivated prescription delivery staff who are well educated in satisfying patient expectations, exceeding the ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/mobile-pharmacy" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>

                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/ambulance">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/ambulance.png" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-ambulance  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/other-services">Ambulance</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy ...</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/ambulance" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>
                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/councelling-psychologist">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/other-services.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-medkit  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/other-services">Counselling </a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy  ....</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/councelling-psychologist" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>


                                                                                        </ul>

                                                                                        <ul class="mkdf-portfolio-slider-list" data-columns="3" data-enable-pagination="yes">

                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/dietitian">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/dietician.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-medkit  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/dietitian">Dietitian</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy  ....</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/dietitian" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>


                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/speech-therapy">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/speech.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-medkit  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/speech-therapy">Speech Therapy</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy  ....</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/speech-therapy" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>


                                                                                                <li class="mkdf-ptfs-item-holder mkdf-ptfs-item-with-icon post-1332 portfolio-item type-portfolio-item status-publish has-post-thumbnail hentry portfolio-category-recepies">
                                                                                                        <div class="mkdf-ptfs-item">
                                                                                                                <div class="mkdf-ptfs-item-image">
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/other-services">
                                                                                                                                <img width="800" height="600" src="<?= Yii::$app->homeUrl; ?>images/services/other-services.jpg" class="attachment-wellspring_mikado_landscape size-wellspring_mikado_landscape wp-post-image" alt="p" /> </a>
                                                                                                                </div>
                                                                                                                <div class="mkdf-ptfs-item-content">
                                                                                                                        <div class="mkdf-ptfs-item-icon-holder">
                                                                                                                                <i style="color: rgb(19, 168, 176);font-size: 43px;" class="fa fa-medkit  attachment-thumbnail size-thumbnail" aria-hidden="true"></i>
                                                                                                                        </div>
                                                                                                                        <h5 class="mkdf-ptfs-item-title">
                                                                                                                                <a href="<?= Yii::$app->homeUrl; ?>services/other-services">Other Services</a>
                                                                                                                        </h5>
                                                                                                                        <div class="mkdf-ptfs-item-excerpt-holder">
                                                                                                                                <p>We also have several other services which could benefit you to lead an independent lifestyle.
                                                                                                                                        These are in addition to offering a wide and ...
                                                                                                                                        .</p>
                                                                                                                        </div>
                                                                                                                        <a href="<?= Yii::$app->homeUrl; ?>services/other-services" target="_self" class="read-more mkdf-btn mkdf-btn-medium mkdf-btn-solid mkdf-btn-hover-outline">

                                                                                                                                <span class="mkdf-btn-text">Read More</span>
                                                                                                                        </a>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </li>



                                                                                        </ul>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>

                                <!------------------------------testimonial-------------------------------------------->

                                <div class="vc_row wpb_row vc_row-fluid mkdf-section mkdf-content-aligment-left mkdf-video" style="">
                                        <div class="mkdf-mobile-video-image" style="background-image:url(_http_/wellspring.mikado-themes.com/wp-content/uploads/2016/01/health-video-screenshot-1.html);"></div>
                                        <div class="mkdf-video-overlay"></div>
                                        <div class="mkdf-video-wrap">
                                                <video class="mkdf-video" width="1920" height="800" poster="wp-content/uploads/2016/01/health-video-screenshot-1.jpg" controls="controls" preload="metadata" loop autoplay muted>
                                                        <source type="video/webm" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/02/health-video-1.webm">
                                                        <source type="video/mp4" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/02/health-video-1.mp4">
                                                        <source type="video/ogg" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/02/health-video-1.ogv">
                                                        <object width="320" height="240" type="application/x-shockwave-flash" data="wp-content/themes/wellspring/assets/js/flashmediaelement.swf">
                                                                <param name="movie" value="http://wellspring.mikado-themes.com/wp-content/themes/wellspring/assets/js/flashmediaelement.swf" />
                                                                <param name="flashvars" value="controls=true&amp;file=http://wellspring.mikado-themes.com/wp-content/uploads/2016/02/health-video-1.mp4" /><img src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/health-video-screenshot-1.jpg" width="1920" height="800" title="No video playback capabilities" alt="Video thumb" /></object>
                                                </video>
                                        </div>
                                        <div class="clearfix mkdf-full-section-inner">
                                                <div class="wpb_column vc_column_container vc_col-sm-12">
                                                        <div class="vc_column-inner ">
                                                                <div class="wpb_wrapper">
                                                                        <div class="mkdf-section-title-holder">
                                                                                <h2 class="mkdf-section-title mkdf-section-title-large" style="color: #ffffff;text-align: center">
                                                                                        Happy Customers</h2>
                                                                        </div>
                                                                        <div class="mkdf-testimonials-holder clearfix light">
                                                                                <div class="mkdf-testimonials testimonials-slider">
                                                                                        <div id="mkdf-testimonials114" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/rama.jpg" class="attachment-114 size-114 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/rama.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Inadequacy of qualified persons to take care of elderly people is a problem faced by large number of households in the state. Many old people are affected by diseases like diabetics, hypertension etc. and several people are bed ridden on account of various ailments. People with training in nursing only can take care of these old and laid up people. "Caring People" in this regard is rendering very valuable service to the community by supplying qualified persons to serve old and the sick. I am of the view that people with suitable training in nursing only should be engaged to take care of old and sick people. </p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Justice C N Ramachandran Nair</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>
                                                                                        <div id="mkdf-testimonials113" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/achan.jpg" class="attachment-113 size-113 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/achan.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">As the new generation finds much pain to take care of the aged and bedridden ones who are so near and dear to them here an open door set by “ CARING PEOPLE, Cochin & Mumbai” is always admirable. Any person in need of nursing assistance can approach them for proper guidance and avail their valuable nursing support from their qualified and experienced nurses.
                                                                                                                                        In fact not taking care of the aged and sick ones can be considered as a human rights and violation. Therefore the act of “ CARING PEOPLE “ is indeed commendable and remains a blessing to the needy ones. I wish all the best to the people who are behind this selfless service </p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Dr P C Achankunju M.A, Ph.D.</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>
                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/sree.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/sree.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Caring People Home Care provides amazing service!
                                                                                                                                        My personal experience with Caring people has been extremely smooth and pleasant. I hired baby care nurse for my 5month old baby. Nurses were dedicated and very caring. Caring People bureau were also very helpful and understanding in case of replacing the nurse with immediate effect and personal involvement. Thank u for the exceptional care you have showed for my baby. I really appreciate caring people and their team for their amazing services. I look forward for their services for the coming baby too.
                                                                                                                                        I will recommend caring people nursing bureau to anyone.
                                                                                                                                        Thank you so much for the love and services.  </p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Mrs.Bhuvneshwari Sreesanth</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/subra-1.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/subra-1.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">I have been associated with caring people from its inception. In fact, I attended their inaugural function to launch their services. What attracted me from the beginning of the association was the foresight of the persons behind the organisation who, themselves being qualified nursing practitioners who realised the need for a service agency to provide quality nursing care to the needy in the public. They, from the beginning insisted from being different from the home nurse caregivers organisations by providing qualified nurses to homes and hospitals for personalised attention of the needy patients. They have been successful in their venture. I have personally recommended their services to many of our patients who needed home nursing care ranging from palliative nursing to intensive nursing. I am happy to say that the feedback received from the families has been excellent.
                                                                                                                                        I wish the group continued success and growth.  </p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Dr. Subramania Iyer</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/ganga.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/ganga.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">From my experience, I have no hesitation to certify that Caring People is a reliable organisation who provide the service of trained and qualified nurses for caring the needy people.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Dr. V P Gangadharan</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/justice.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/justice.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Caring People, an agency engaged in in-house services like Nursing Care at home, has been providing Nurses to look after my elderly mother-in-law.
                                                                                                                                        The services provided by the institution, are up to the mark and are of great help to the patient and to the members of the family.
                                                                                                                                        The institution is discharging a great service to the Society at large, which I acknowledge with gratitude. The persons in need can always avail off its services.I wish the institution all success in their endeavour.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Justice KSP Radhakrishnan</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/remy.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/remy.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">We do appreciate the efforts taken by the whole team of Caring people for doing such a great job in taking care of our relative Samachayan. Your service was top notch and I appreciate how much easier you made things for him in the last couple of months.I would highly recommend your services and appreciate everything you did. Thank you all for your care.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Remy Thomas</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/elias.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/elias.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">I would like to convey our deepest thanks to you all at caring People, everyone in the office and all the cares for all the work and help you have given over the past 3 years.
                                                                                                                                        We would have no hesitation in thoroughly recommending Caring People to anyone else and that they need look no further.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Y. M. Elias</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/Joe-Mathew-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/Joe-Mathew-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Happy to give you a feedback on the service your organisation has rendered.Caring People has provided qualified nurses for nursing my parents. Their knowledge, skill and care are their strength. Such a service is not common and will be a big boon for the aged and bed-ridden. I wholeheartedly recommend their service at times of need.Wishing them the very best in giving Health Care at one's doorstep.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Joe Mathew</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/Sindhu-Nair-Pic-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/Sindhu-Nair-Pic-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Thank you for all the support and service Your team has provided for us during our painful time. Also, I would like to inform you that in future if we need or anyone else need such support we will surely remember your name.Once again our heartfelt thanks to your team.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Sindhu Nair</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/femaleicon-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/femaleicon-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">My family and I would like to thank your agency for providing such amazing service for the old and sick people recuperating at home or in the hospital. We were very impressed with the staff provided by Caring People. The service provided was "impeccable".We would like to thank all the caregivers for their services & tender care provided to our father Major. P.V Varghese(Rtd). All the staff members were honest, diligent, hardworking and above all caring, especially as we were all out of town/country, during the time that we needed your service.We would specially like to mention the wonderful service of Tom who was so well linked by my father. Tom provided so much of joy to my father during his last days. Tom was like an "angel" in my father's life.We strongly recommend Caring People's services to any person who needs them.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Elizebeth Koshy</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/Ranjith-Vadakkan-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/Ranjith-Vadakkan-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">I have been using the services of Caring People from 2015 onwards for my father and have contnued their services for my mother now.I recommend them to all looking for reliable old age care services and endorse that Mr.Shinto and his Staff's are very passionate & proffesional towards their work. They have successfully organised the rather unorganised sector and wish them all the very best for their future. Also thanking all the staff at Caring People on the wonderfull service they are providing. God Bless you all....</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Ranjit Vadakkan</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/testrimoni-130x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/testrimoni-130x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">Caring People Home Care provides exceptional services in my experience. Nurses were prompt, dedicated and most importantly humane. The association with you was extremely satisfactory and we would be happy to use your services in the future as well. We would have no hesitation in thoroughly recommending Caring People to anyone else.
                                                                                                                                        I wish you greater success in your endeavors to care for more people in need.</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Dr. Sreekanth Namboothiri</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/femaleicon-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/femaleicon-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">" I got in touch with Caring People after being recommended through a friend. My 65 year mother was slowly getting weak and losing mobility. Caring people team did a home visit and assessed my mother's condition and made a good plan to address muscle strengthening and body balance. Working in health care sector in UK, I have seen the best and worst scenarios of home based care. But my apprehension was dispelled hearing feedback from my mother. She was initially sceptical about the whole process when I suggested home physiotherapy; but now, she is delighted with the progress she is making. I have been really impressed by the professionalism with which the team have dealt with my mother and would highly recommend Caring People"</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Dr.SN</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                        <div id="mkdf-testimonials110" class="mkdf-testimonial-content testimonials-slider">
                                                                                                <div class="mkdf-testimonial-content-inner">
                                                                                                        <div class="mkdf-container-inner">
                                                                                                                <div class="mkdf-testimonial-text-holder">
                                                                                                                        <div class="mkdf-testimonial-text-inner light">
                                                                                                                                <div class="mkdf-testimonial-slider-image-holder">
                                                                                                                                        <img width="122" height="122" src="<?= Yii::$app->homeUrl; ?>images/testimonial/bhatia-150x150.jpg" class="attachment-110 size-110 wp-post-image" alt="p" srcset="<?= Yii::$app->homeUrl; ?>images/testimonial/bhatia-150x150.jpg" sizes="(max-width: 122px) 100vw, 122px" /> </div>
                                                                                                                                <p class="mkdf-testimonial-text" style="padding-left: 200px;padding-right: 200px">It was great to have a nurse from CARING PEOPLE and was a good experience to have their services in our difficult time.
                                                                                                                                        We wish them all the best and success in future.Thank You Once again..</p>
                                                                                                                                <div class="mkdf-testimonial-author">
                                                                                                                                        <h3 class="mkdf-testimonial-author-text light">Bharat Bhatia</h3>
                                                                                                                                </div>
                                                                                                                        </div>
                                                                                                                </div>

                                                                                                        </div>
                                                                                                </div>
                                                                                        </div>

                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>

                                <!------------------------------testimonial-end-------------------------------------------->


                                <!---------------------------------------------about-section------------------------------------>

                                <div class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1453373235263 mkdf-content-aligment-left mkdf-grid-section" style="">
                                        <div class="clearfix mkdf-section-inner">
                                                <div class="mkdf-section-inner-margin clearfix">
                                                        <div class="wpb_column vc_column_container vc_col-sm-12">
                                                                <div class="vc_column-inner ">
                                                                        <div class="wpb_wrapper">
                                                                                <div class="mkdf-section-title-holder">
                                                                                        <h2 class="mkdf-section-title mkdf-section-title-large" style="text-align: left">
                                                                                                Our Name is our Guarantee</h2>
                                                                                        <h3 class="mkdf-item-title">
                                                                                                <!--<a href="#" >-->

                                                                                                <!--</a>-->
                                                                                        </h3>
                                                                                </div>
                                                                                <div data-mkdf-parallax-speed="1" class="vc_row wpb_row vc_inner vc_row-fluid mkdf-section mkdf-content-aligment-right" style="">
                                                                                        <div class="mkdf-full-section-inner">
                                                                                                <div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-12 vc_col-md-12">
                                                                                                        <div class="vc_column-inner ">
                                                                                                                <div class="wpb_wrapper">
                                                                                                                        <div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left">
                                                                                                                                <p style="text-align: left" class="mkdf-section-subtitle">Living in your own surroundings where you feel loved and comfortable is always the best choice when it comes to difficult moments like being unwell. Home care is the right kind of support what people in need always wish for. Caring People Home care offers the best quality care and support at home. Our aim is to enable our needy clients to continue living in their own households with dignity, individuality and with control over their lives, irrespective of the level of support required. Caring People will always work with you to plan a service package that will aid you or your loved one to live a life to the full at home.</p>
                                                                                                                        </div>
                                                                                                                        <div data-original-height="33" class="vc_empty_space" style="height: 33px"><span class="vc_empty_space_inner"></span></div>
                                                                                                                </div>
                                                                                                        </div>
                                                                                                </div>

                                                                                        </div>
                                                                                </div>
                                                                        </div>
                                                                </div>
                                                        </div>
                                                </div>
                                        </div>
                                </div>

                                <!---------------------------------------------about-section-end------------------------------------>

                                <!-------------------------------------------------------------------tab-selector------------------------------>

                                <!--                                <div class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1453982497008 mkdf-content-aligment-left mkdf-grid-section" style=""><div class="clearfix mkdf-section-inner"><div class="mkdf-section-inner-margin clearfix"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mkdf-tabs mkdf-vertical mkdf-tab-text clearfix">
                                                                                                <ul class="mkdf-tabs-nav">
                                                                                                    <li>
                                                                                                        <a href="#tab-get-up-and-go">
                                                                                                            Get up and Go				</a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="#tab-dare-to-be-great">
                                                                                                            Dare To Be Great				</a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="#tab-grown-by-nature">
                                                                                                            Grown by Nature				</a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="#tab-best-fitness-foods">
                                                                                                            Best Fitness Foods				</a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="#tab-ways-to-get-motivated">
                                                                                                            Ways to Get Motivated				</a>
                                                                                                    </li>
                                                                                                    <li>
                                                                                                        <a href="#tab-healthy-snacks">
                                                                                                            Healthy Snacks				</a>
                                                                                                    </li>
                                                                                                </ul>
                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-1.jpg)" id="tab-get-up-and-go" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Eat Good. Feel Good.</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Lorem ipsum dolor sit amet auctor egestas libero arcu. Wisi ante at. Mi pulvinar officiis neque odio magna aliquet pede morbi erat massa egestas.</p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div></div>

                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-2.jpg)" id="tab-dare-to-be-great" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Warm Winter Desserts</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Quis et nec parturient in cursus at placerat amet integer et id. Dolor habitant metus. Enim eu praesent primis quam quis ante laoreet diam sit.</p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div></div>

                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-5.jpg)" id="tab-grown-by-nature" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Healthy and Delicious Recipes</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Odio etiam vivamus convallis fusce tortor. Parturient et mi libero luctus habitant pretium venenatis morbi. Sollicitudin tincidunt rhoncus amet donec sodales. </p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div></div>

                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-6.jpg)" id="tab-best-fitness-foods" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Workout Excuses Busted</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Felis vitae dui facilisis sem malesuada. Etiam lectus fringilla. Metus sit lorem mi vel nunc dolor ipsum amet neque fringilla con. Et porta amet vestibulum.</p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div></div>

                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-4.jpg)" id="tab-ways-to-get-motivated" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Running to the Future</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Et diam tellus nullam dui gravida. Aliquam posuere sollicitudin eros sed mi. Leo sit sit sollicitudin wisi pellentesque aliquam quisque et accumsan.</p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div></div>

                                                                                                <div class="mkdf-tab-container mkdf-tab-image" style="background-image: url(wp-content/uploads/2016/01/tab-background-8.jpg)" id="tab-healthy-snacks" data-icon-pack="font_awesome" data-icon-html="&lt;i class=&quot;mkdf-icon-font-awesome fa  &quot; &gt;&lt;/i&gt;">
                                                                                                    <div data-original-height="20" class="vc_empty_space"  style="height: 20px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div class="mkdf-section-title-holder">
                                                                                                        <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                            Creating Healthier Lives</h2>
                                                                                                    </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                        <p style="text-align: left" class="mkdf-section-subtitle">Non at arcu nonummy tristique tortor. Sed quisque pellentesque. Posuere sapien quam accumsan nullam ut. Molestie dui quisque. Fringilla pellentesque.</p>
                                                                                                    </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                                    <div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Healthy Desserts Shockingly High in Protein.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A natural way of improving your health.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Train Yourself to Exercise in the Morning in Just One Week.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Enhancing the personal healing experience.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > A Whole New Way to Take Your Vitamins.</p>
                                                                                                    </div><div  class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                        <div class="mkdf-icon-list-icon-holder">
                                                                                                            <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                <span aria-hidden="true" class="mkdf-icon-font-elegant icon_check " style="color:#4fbf70;font-size:18px" ></span>		</div>
                                                                                                        </div>
                                                                                                        <p class="mkdf-icon-list-text"  > Smoothie Recipes Loaded with Winter Superfoods.</p>
                                                                                                    </div></div>

                                                                                            </div>

                                                                                        </div></div></div></div></div></div>-->

                                <!-------------------------------------------------------------------tab-selector-end------------------------------>

                                <!--                                <div class="vc_row wpb_row vc_row-fluid mkdf-section vc_custom_1454930627059 mkdf-content-aligment-left mkdf-grid-section" style=""><div class="clearfix mkdf-section-inner"><div class="mkdf-section-inner-margin clearfix"><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mkdf-section-title-holder">
                                                                                                <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left">
                                                                                                    Clients / Partners</h2>
                                                                                            </div><div class="mkdf-section-subtitle-holder mkdf-section-subtitle-left" >
                                                                                                <p style="text-align: left" class="mkdf-section-subtitle">Lorem ipsum dolor sit amet facilisis sed vitae lorem pede at eu arcu vulputate metus luctus ut quis vivamus vitae id habitasse.</p>
                                                                                            </div><div data-original-height="42" class="vc_empty_space"  style="height: 42px" ><span class="vc_empty_space_inner"></span></div>
                                                                                            <div class="mkdf-carousel-holder clearfix mkdf-carousel-three-rows mkdf-carousel-navigation"><div class="mkdf-carousel " data-items="3" data-navigation="yes"><div class="mkdf-carousel-item-outer-holder border"><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-1.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-4.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-7.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div></div><div class="mkdf-carousel-item-outer-holder border"><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-2.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-5.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-8.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div></div><div class="mkdf-carousel-item-outer-holder border"><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-3.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-6.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div><div class="mkdf-carousel-item-holder">
                                                                                                            <span class="mkdf-carousel-first-image-holder  mkdf-image-zoom">
                                                                                                                <img width="217" height="98" src="<?= Yii::$app->homeUrl; ?>wp-content/uploads/2016/01/client-9.png" class="attachment-full size-full" alt="p" />			</span>
                                                                                                        </div></div></div></div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                        </div></div></div><div class="wpb_column vc_column_container vc_col-sm-12 vc_col-lg-6 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="mkdf-section-title-holder">
                                                                                                <h2 class="mkdf-section-title mkdf-section-title-medium" style="text-align: left;margin-bottom: 30px">
                                                                                                    What We Offer</h2>
                                                                                            </div><div class="mkdf-accordion-holder clearfix mkdf-accordion mkdf-boxed ">
                                                                                                <h5 class="clearfix mkdf-title-holder">
                                                                                                    <span class="mkdf-accordion-mark mkdf-left-mark">
                                                                                                        <span class="mkdf-accordion-mark-icon">
                                                                                                            <span class="icon_plus"></span>
                                                                                                            <span class="icon_minus-06"></span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="mkdf-tab-title">
                                                                                                        <span class="mkdf-tab-title-inner">
                                                                                                            Body balance		</span>
                                                                                                    </span>
                                                                                                </h5>
                                                                                                <div class="mkdf-accordion-content">
                                                                                                    <div class="mkdf-accordion-content-inner">
                                                                                                        <div style="margin-bottom: 10px" class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                            <div class="mkdf-icon-list-icon-holder">
                                                                                                                <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                    <span aria-hidden="true" class="mkdf-icon-font-elegant icon_clock_alt " style="color:#808080;font-size:14px" ></span>		</div>
                                                                                                            </div>
                                                                                                            <p class="mkdf-icon-list-text" style="color:#808080;font-size:14px;font-weight: 700;padding-left: 10px" > 45 MINUTES</p>
                                                                                                        </div>
                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p><a href="#">Read More</a></p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                    </div>
                                                                                                </div>
                                                                                                <h5 class="clearfix mkdf-title-holder">
                                                                                                    <span class="mkdf-accordion-mark mkdf-left-mark">
                                                                                                        <span class="mkdf-accordion-mark-icon">
                                                                                                            <span class="icon_plus"></span>
                                                                                                            <span class="icon_minus-06"></span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="mkdf-tab-title">
                                                                                                        <span class="mkdf-tab-title-inner">
                                                                                                            Zumba		</span>
                                                                                                    </span>
                                                                                                </h5>
                                                                                                <div class="mkdf-accordion-content">
                                                                                                    <div class="mkdf-accordion-content-inner">
                                                                                                        <div style="margin-bottom: 10px" class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                            <div class="mkdf-icon-list-icon-holder">
                                                                                                                <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                    <span aria-hidden="true" class="mkdf-icon-font-elegant icon_clock_alt " style="color:#808080;font-size:14px" ></span>		</div>
                                                                                                            </div>
                                                                                                            <p class="mkdf-icon-list-text" style="color:#808080;font-size:14px;font-weight: 700;padding-left: 10px" > 1 HOUR 15 MINUTES</p>
                                                                                                        </div>
                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi.</p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p><a href="#">Read More</a></p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                    </div>
                                                                                                </div>
                                                                                                <h5 class="clearfix mkdf-title-holder">
                                                                                                    <span class="mkdf-accordion-mark mkdf-left-mark">
                                                                                                        <span class="mkdf-accordion-mark-icon">
                                                                                                            <span class="icon_plus"></span>
                                                                                                            <span class="icon_minus-06"></span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="mkdf-tab-title">
                                                                                                        <span class="mkdf-tab-title-inner">
                                                                                                            Basic Pilates		</span>
                                                                                                    </span>
                                                                                                </h5>
                                                                                                <div class="mkdf-accordion-content">
                                                                                                    <div class="mkdf-accordion-content-inner">
                                                                                                        <div style="margin-bottom: 10px" class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                            <div class="mkdf-icon-list-icon-holder">
                                                                                                                <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                    <span aria-hidden="true" class="mkdf-icon-font-elegant icon_clock_alt " style="color:#808080;font-size:14px" ></span>		</div>
                                                                                                            </div>
                                                                                                            <p class="mkdf-icon-list-text" style="color:#808080;font-size:14px;font-weight: 700;padding-left: 10px" > 1 HOUR 30 MINUTES</p>
                                                                                                        </div>
                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p>Nam vehicula commodo pulvinar. Morbi vel luctus dui. Maecenas faucibus dignissim ante, et sollicitudin eros rutrum viverra. Sed viverra leo eget aliquam ultricies. Lorem ipsum.</p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p><a href="#">Read More</a></p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                    </div>
                                                                                                </div>
                                                                                                <h5 class="clearfix mkdf-title-holder">
                                                                                                    <span class="mkdf-accordion-mark mkdf-left-mark">
                                                                                                        <span class="mkdf-accordion-mark-icon">
                                                                                                            <span class="icon_plus"></span>
                                                                                                            <span class="icon_minus-06"></span>
                                                                                                        </span>
                                                                                                    </span>
                                                                                                    <span class="mkdf-tab-title">
                                                                                                        <span class="mkdf-tab-title-inner">
                                                                                                            Yoga Zen		</span>
                                                                                                    </span>
                                                                                                </h5>
                                                                                                <div class="mkdf-accordion-content">
                                                                                                    <div class="mkdf-accordion-content-inner">
                                                                                                        <div style="margin-bottom: 10px" class="mkdf-icon-list-item mkdf-icon-list-item-default-font-family">
                                                                                                            <div class="mkdf-icon-list-icon-holder">
                                                                                                                <div class="mkdf-icon-list-icon-holder-inner clearfix">
                                                                                                                    <span aria-hidden="true" class="mkdf-icon-font-elegant icon_clock_alt " style="color:#808080;font-size:14px" ></span>		</div>
                                                                                                            </div>
                                                                                                            <p class="mkdf-icon-list-text" style="color:#808080;font-size:14px;font-weight: 700;padding-left: 10px" > 30 MINUTES</p>
                                                                                                        </div>
                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation.</p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                        <div class="wpb_text_column wpb_content_element ">
                                                                                                            <div class="wpb_wrapper">
                                                                                                                <p><a href="#">Read More</a></p>

                                                                                                            </div>
                                                                                                        </div>

                                                                                                    </div>
                                                                                                </div>
                                                                                            </div><div data-original-height="40" class="vc_empty_space"  style="height: 40px" ><span class="vc_empty_space_inner"></span></div>
                                                                                        </div></div></div></div></div></div>-->
                        </div>
                </div>
                <div class="mkdf-content-bottom" style="background-color: #2a2b2a">
                        <div class="mkdf-container">
                                <div class="mkdf-container-inner clearfix">
                                </div>
                        </div>
                </div>
                <!-- close div.content_inner -->
        </div>
        <!-- close div.content -->
